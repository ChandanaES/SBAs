package com.iiht.evaluation.eloan.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Iterator;

public class Test {

	//private Connection jdbcConnection;
	//private Statement jdbcStatement;
	//private ResultSet jdbcResultSet;
	public static void main(String[] args) {
		ConnectionDao connDao = new ConnectionDao("jdbc:mysql://localhost:3306/ibs", "root", "Rajesh.1108");
		try {
			Connection conn = connDao.connect();
			Statement jdbcStatement = connDao.createStatement();
			ResultSet rs = jdbcStatement.executeQuery("select * from ibs.kyc");
			System.out.println("connn>>>>>"+conn.isClosed());
			System.out.println("row>>>>>"+rs.getRow());
			while(rs.next()) {
				System.out.println("rs>>>>>"+rs.getInt(1)
						+ " | " + rs.getString(2)
						+ " | " + rs.getString(3)
						+ " | " + rs.getInt(4)
						+ " | " + rs.getString(5));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	

	
	
	/*public void fireQuery() throws SQLException {
		//int n = createStatement().executeUpdate("");
		
		//select
		jdbcResultSet = createStatement().executeQuery("select * from kyc");
		
		//move the cursor one step
		if (jdbcResultSet.next()) {
			String firstName = jdbcResultSet.getString("First Name");
		}
		
		while (jdbcResultSet.next()) {
			System.out.println(jdbcResultSet.getInt(1)
					+ " | " + jdbcResultSet.getString(2)
					+ " | " + jdbcResultSet.getString(3)
					+ " | " + jdbcResultSet.getInt(4)
					+ " | " + jdbcResultSet.getString(5));
		}
		
		jdbcResultSet.close();
		
	}
	
	public  Connection connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		}
		
		return jdbcConnection;
	}*/

}
